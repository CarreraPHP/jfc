angular.js library is used for this project. pls check version .txt for the current version in use.
